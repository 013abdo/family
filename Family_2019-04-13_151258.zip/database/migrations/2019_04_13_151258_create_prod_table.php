<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;

class CreateProdTable extends Migration {

	public function up()
	{
		Schema::create('prod', function(Blueprint $table) {
			$table->increments('id');
			$table->string('Name', 45);
			$table->longText('Descript');
			$table->string('type', 20);
			$table->longText('Photo');
			$table->char('Class', 5);
			$table->decimal('Price');
			$table->integer('Quant');
			$table->boolean('status');
		});
	}

	public function down()
	{
		Schema::drop('prod');
	}
}