<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;

class CreateBookingTable extends Migration {

	public function up()
	{
		Schema::create('Booking', function(Blueprint $table) {
			$table->increments('id');
			$table->timestamps();
			$table->date('Date');
			$table->integer('Quant');
			$table->string('Item', 45);
			$table->decimal('Price');
			$table->decimal('Deli-cost');
			$table->boolean('Odr-status');
			$table->datetimeTz('Receive-date');
			$table->date('Remain-time');
		});
	}

	public function down()
	{
		Schema::drop('Booking');
	}
}