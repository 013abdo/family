<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;

class CreateKitchenTable extends Migration {

	public function up()
	{
		Schema::create('Kitchen', function(Blueprint $table) {
			$table->increments('id');
			$table->string('name', 45);
			$table->string('Acc', 100);
			$table->string('Owner', 50);
			$table->string('Address', 100);
			$table->string('Email', 100);
			$table->integer('Tel');
			$table->integer('Phone');
		});
	}

	public function down()
	{
		Schema::drop('Kitchen');
	}
}