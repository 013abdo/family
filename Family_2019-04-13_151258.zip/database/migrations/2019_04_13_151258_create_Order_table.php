<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;

class CreateOrderTable extends Migration {

	public function up()
	{
		Schema::create('Order', function(Blueprint $table) {
			$table->increments('id');
			$table->date('Date');
			$table->time('Time');
			$table->decimal('Price');
			$table->string('Item', 20);
			$table->boolean('Status');
			$table->string('Deli-name', 45);
			$table->timeTz('Deli-time');
			$table->integer('mobile');
		});
	}

	public function down()
	{
		Schema::drop('Order');
	}
}