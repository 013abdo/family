<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;

class CreateFmilyTable extends Migration {

	public function up()
	{
		Schema::create('Fmily', function(Blueprint $table) {
			$table->increments('id');
			$table->string('name', 45);
			$table->string('Owner', 45);
			$table->string('Address', 100);
			$table->string('Acc', 100);
			$table->integer('Tel');
			$table->integer('Phone');
			$table->string('Email', 50);
		});
	}

	public function down()
	{
		Schema::drop('Fmily');
	}
}