<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;

class CreateUserTable extends Migration {

	public function up()
	{
		Schema::create('user', function(Blueprint $table) {
			$table->increments('id');
			$table->timestamps();
			$table->string('Fname', 45);
			$table->string('Lname', 45);
			$table->string('Address', 100);
			$table->string('Acc', 50);
			$table->integer('Phone');
			$table->string('Uname', 40);
			$table->string('Upass', 40);
		});
	}

	public function down()
	{
		Schema::drop('user');
	}
}