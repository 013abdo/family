<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;

class CreateIMGTable extends Migration {

	public function up()
	{
		Schema::create('IMG', function(Blueprint $table) {
			$table->increments('id');
			$table->longText('Photo-name');
			$table->longText('file');
			$table->char('qulity');
			$table->decimal('size');
		});
	}

	public function down()
	{
		Schema::drop('IMG');
	}
}